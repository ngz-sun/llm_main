## Tiny LLM Datsets 下载

### 1.下载链接

- 链接：https://pan.baidu.com/s/1I5LYq3tu-_pFl0zu4wMpRg?pwd=tiny 
- 提取码：tiny

### 2.数据集介绍

- chatglm3_tokenizer : tokenizer文件夹
- pre_train : 预训练 token
- rl_train : 偏好数据集
- sft_train : 微调数据集
- README.md : 数据集详解



